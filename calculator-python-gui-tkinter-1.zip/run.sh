pip install slackclient
python calculator.py